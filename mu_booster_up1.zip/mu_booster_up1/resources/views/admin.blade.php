@extends('layouts.master_admin')
@section('title')
    Dashboard
@endsection
@section('content')
    <div class="faculty_area">
        <div class="admin_body">
            <h1>Admin Panel</h1>
        </div>
    </div>
@endsection