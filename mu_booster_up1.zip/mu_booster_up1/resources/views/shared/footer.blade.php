<!-- Start Footer Area -->
<footer class="footer_area">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="footer_logo">
                    <a href=""><p>MU-Booster</p>
                    </a>
                    <p>We understand the demand of customers. Base on that, we want to co-operate with customer to create the products and solutions with the best benefit at the economical fee.</p>
                </div>
            </div>
        </div>
        <div class="footer_menu">
            <div class="row">
                <div class="col-md-12 text-center text-white">
                    <div class="footer_right">
                        <p>&copy; 2016 <a href="">Mu-Booster</a> Design BY <span>Nisha</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Area -->