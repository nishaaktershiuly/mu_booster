<?php /* F:\php\htdocs\demo\resources\views/shared/header.blade.php */ ?>
<!-- Start Header Menu Area   -->
<header class="main_menu_area sticky">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="header_logo">
                    <a href=""><p>MU-Booster</p>
                    </a>
                </div>
            </div>
            <div class="col-md-8">
                <div class="main_menu">
                    <nav class="navbar navbar-expand-lg navbar-light ">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul>
                                <li>
                                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Programmes
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item transition" href="<?php echo e(action('Department\DepartmentController@index')); ?>"><i class="fas fa-caret-right"></i>department of CSE</a>
                                        <a class="dropdown-item transition" href="#"><i class="fas fa-caret-right"></i>department of EEE</a>
                                        <a class="dropdown-item transition" href="#"><i class="fas fa-caret-right"></i>department of Economics</a>
                                        <a class="dropdown-item transition" href="#"><i class="fas fa-caret-right transition"></i>department of Law </a>
                                        <a class="dropdown-item transition" href="#"><i class="fas fa-caret-right transition"></i>department of English</a>
                                        <a class="dropdown-item transition" href="#"><i class="fas fa-caret-right transition"></i>department of BBA</a>
                                    </div>
                                </li>
                                <li>
                                    <a class="nav-link" href="#">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="col-md-1 text-right">
                <div class="header_icon">
                    <ul>
                        <li>
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="fas fa-user"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>