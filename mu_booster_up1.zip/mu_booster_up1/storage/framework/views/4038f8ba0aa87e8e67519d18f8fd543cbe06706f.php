<?php /* C:\xampp\htdocs\mu_booster_up1\resources\views/shared/admin/header.blade.php */ ?>
<div class="header_right">
    <ul>
        <li><a href="#"><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="#"><img src="<?php echo e(asset('public/admin_asset/images/user.jpg')); ?>" alt="" /><i class="fas fa-arrow-down"></i>
            </a>
            <ul>
                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">logout</a></li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </ul>
        </li>
    </ul>
</div>