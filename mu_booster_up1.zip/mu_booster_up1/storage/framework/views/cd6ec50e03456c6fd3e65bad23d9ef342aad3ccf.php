<?php /* C:\xampp\htdocs\mu_booster_up1\resources\views/layouts/app.blade.php */ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Mu-Booster</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/fontawesome-all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bicon.min.css')); ?>" />
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/owl.carousel.min.css')); ?>" />
    <!-- Site favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('public/assets/images/favicon.ico')); ?>">
    <!-- Animate Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/animate.css')); ?>" />
    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" />
    <!-- Main Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>" media="all" />
    <?php echo $__env->yieldContent('style'); ?>

</head>
<body>
    <?php echo $__env->make('shared.app_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- LinkUp Js -->
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/onepagenav.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/isotope.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/waypoints.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/jquery.counterup.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/wow.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/ityped.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/active.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
