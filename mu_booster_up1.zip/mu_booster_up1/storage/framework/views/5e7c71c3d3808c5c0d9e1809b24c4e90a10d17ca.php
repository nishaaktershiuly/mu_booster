<?php /* C:\xampp\htdocs\mu_booster_up1\resources\views/box/semester/semester.blade.php */ ?>
<?php $__env->startSection('box'); ?>
<!-- Create Semester Modal -->
	 <div class="modal modal_zindex fade" id="createModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-edit"></i> Add Semester</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(action('Admin\Semester\SemesterController@save')); ?>" method="post" enctype="multipart/form-data">
						 <?php echo csrf_field(); ?>


                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group input-group-sm mb-2">
									<label for="name">Semester Name</label>
									<input type="text" class="form-control" id="name" name="name" placeholder="Semester Name">
								</div>
								<?php if($errors->has('name')): ?>
									<ul>
										<li style="color:red;"><?php echo e($errors->first('name')); ?></li>
									</ul>
								<?php endif; ?>
								<div class="form-group input-group-sm mb-2">
                                    <label for="dept">Department</label>
                                    <select class="form-control" name="deptID">
                                        <option>select department</option>
                                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
								<?php if($errors->has('deptID')): ?>
									<ul>
										<li style="color:red;"><?php echo e($errors->first('deptID')); ?></li>
									</ul>
								<?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-sm btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

	
	<!-- Edit Modal -->
	<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle1" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLongTitle1">EDIT SEMESTER</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo e(action('Admin\Semester\SemesterController@edit')); ?>" id="editFacultyForm" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<input type="hidden" name="id">

			<div class="modal-body">
				<div class="faculty_area">
					<div class="faculty_body">
							<div class="form-group input-group-sm mb-2">
								<label for="name">Name</label>
								<input type="text" class="form-control" id="name" name="name" placeholder="Semester Name">
							</div>
							<div class="form-group input-group-sm mb-2">
								<label for="dept">Department</label>
								<select class="form-control" name="deptID">
									<option>select department</option>
									<?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-sm btn-primary">Save changes</button>
			</div>
			</form>
		</div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>