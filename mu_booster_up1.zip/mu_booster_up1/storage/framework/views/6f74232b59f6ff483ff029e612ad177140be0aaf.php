<?php /* E:\xampp\htdocs\mu_booster_up\resources\views/box/course_details/course_details.blade.php */ ?>
<?php $__env->startSection('box'); ?>
	<div class="modal modal_zindex fade" id="createModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-plus-square"></i> Add Course Component</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                  <form action="<?php echo e(action('Admin\Course_details\Course_detailsController@save')); ?>" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                 

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
								 <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Course Name</label>
                                    <select class="form-control" name="course_name">
                                        <option>select course</option>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Department Name</label>
                                    <select class="form-control" name="deptID">
                                        <option>select Department</option>
                                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Semester</label>
                                    <select class="form-control" name="semester">
                                        <option>Semester</option>
                                        <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="book_name">Book Name</label>
                                    <input id="book_name" type="text" placeholder="Book Name" name="book_name" class="form-control" >
                                </div>
								<div class="form-group input-group-sm mb-2">
                                    <label for="pdf">Pdf Link</label>
                                    <input id="pdf" type="text" placeholder="Pdf Link" name="pdf" class="form-control" >
                                </div>
								<div class="form-group input-group-sm mb-2">
                                    <label for="software">Software Name</label>
                                    <input id="software" type="text" placeholder="Software Name" name="software" class="form-control" >
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-sm btn-primary">Save </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
	<!-- edit -->
	<!-- Modal -->
	<div class="modal fade" id="edit1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle1" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLongTitle1">Edit SEMESTER COMPONENT</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo e(action('Admin\Course_details\Course_detailsController@edit')); ?>" id="editCourseDetails" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                 
					<input type="hidden" name="id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
								 <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Course Name</label>
                                    <select class="form-control" name="course_name">
                                        <option>select course</option>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Department Name</label>
                                    <select class="form-control" name="deptID">
                                        <option>select Department</option>
                                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="dept">Semester</label>
                                    <select class="form-control" name="semester">
                                        <option>Semester</option>
                                        <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group input-group-sm mb-2">
                                    <label for="book_name">Book Name</label>
                                    <input id="book_name" type="text" placeholder="Book Name" name="book_name" class="form-control" >
                                </div>
								<div class="form-group input-group-sm mb-2">
                                    <label for="pdf">Pdf Link</label>
                                    <input id="pdf" type="text" placeholder="Pdf Link" name="pdf" class="form-control" >
                                </div>
								<div class="form-group input-group-sm mb-2">
                                    <label for="software">Software Name</label>
                                    <input id="software" type="text" placeholder="Software Name" name="software" class="form-control" >
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-sm btn-primary">Save changes</button>
                    </div>
                </form>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>