<?php /* C:\xampp\htdocs\mu_booster_up1\resources\views/admin/user/user.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    User List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="faculty_area">
        <div class="admin_body">
            <div class="search_area">
                <h2>All User List</h2>
            </div>
            <div class="faculty_list">
                <table class="table table-striped" id="dataTable">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">Name</th>
                        <th scope="col">User Roll</th>
                        <th class="text-right" scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($row->id); ?></th>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->userType); ?></td>
                            <td class="text-right">
                                <!-- Button trigger modal -->
                                <a type="button" class="btn btn-sm btn-success ediBtn" data-id="<?php echo e($row->id); ?>" data-roll="<?php echo e($row->userType); ?>" data-toggle="modal" data-target="#ediModal">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="<?php echo e(action('Admin\User\UserController@del',['id' => $row->id])); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('.ediBtn').click(function () {
                var id = $(this).data('id');
                var roll = $(this).data('roll');

                $('#ediForm [name=id]').val(id);
                $('#ediForm [name=userType]').val(roll);

            });
        });
		
        $(function () {
            $('#dataTable').DataTable({
                "order": [[ 0, "DESC" ]],
                "iDisplayLength": 25,
                "columnDefs": [
                    { "orderable": false, "targets": [4]}//For Column Order
                ]
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('box.user.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>