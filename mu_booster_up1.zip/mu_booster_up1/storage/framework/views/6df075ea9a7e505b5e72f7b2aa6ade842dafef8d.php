<?php /* E:\xampp\htdocs\mu_booster_up\resources\views/admin/course_details/course_details.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Course Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
				<div class="faculty_area">
					<div class="admin_body">
						<div class="add_faculty">
							<!-- Button trigger modal -->
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal">
								Add Semester Component
							</button>
							
						</div>		
						<div class="faculty_list">
							<table class="table" id="dataTable">
								<thead class="thead-dark">
									<tr>
									  <th scope="col">id</th>
									  <th scope="col">Course Name</th>
									  <th scope="col">Book Name</th>
									  <th scope="col">pdf</th>
									  <th scope="col">slide</th>
									  <th scope="col">software Download</th>
									  <th scope="col">DepartmentName</th>
									  <th scope="col">SemesterName</th>
									  <th scope="col">Action</th>
									</tr>
								</thead>
								<tbody>
								 <?php
									$i = 1;
								?>
								<?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<th scope="row"><?php echo e($i++); ?></th>
										<td><?php echo e($row->course['name']); ?></td>
										<td><?php echo e($row->book_name); ?></td>
										<td><a href=""><?php echo e($row->pdf); ?></a></td>
										<td><a href=""><?php echo e($row->slide); ?></a></td>
										<td><a href=""><?php echo e($row->software); ?></a></td>
										<td><?php echo e($row->dept['name']); ?></td>
										<td><?php echo e($row->semester['name']); ?></td>
										
										
										<td>
											<a data-id="<?php echo e($row->id); ?>" data-name="<?php echo e($row->course_name); ?>"
												data-dept="<?php echo e($row->deptID); ?>" data-semest="<?php echo e($row->semester); ?>"  data-book_name="<?php echo e($row->book_name); ?>" data-pdf="<?php echo e($row->pdf); ?>" data-software="<?php echo e($row->software); ?>" type="button" class="btn btn-sm btn-success editModal" data-toggle="modal" data-target="#edit1">
											<i class="fa fa-edit"></i>
											</a>
											
											<a href="<?php echo e(action('Admin\Course_details\Course_detailsController@del',['id' => $row->id])); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
   <script type="text/javascript">
	$(function () {
           $('.editModal').click(function () {
               var id = $(this).data('id');
               var name = $(this).data('name');
               var dept = $(this).data('dept');
               var semest = $(this).data('semest');
               var book_name = $(this).data('book_name');
               var pdf = $(this).data('pdf');
               var software = $(this).data('software');

               $('#editCourseDetails [name=id]').val(id);
               $('#editCourseDetails [name=course_name]').val(name);
               $('#editCourseDetails [name=deptID]').val(dept);
               $('#editCourseDetails [name=semester]').val(semest);
               $('#editCourseDetails [name=book_name]').val(book_name);
               $('#editCourseDetails [name=pdf]').val(pdf);
               $('#editCourseDetails [name=software]').val(software);
              

           });
       });
   
   
   $(function () {
		   $('#dataTable').DataTable({
			   "order": [[ 0, "DESC" ]],
			   "iDisplayLength": 10,
			   "columnDefs": [
				   { "orderable": false, "targets": 5 }
			   ]
		   });
	   });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('box.course_details.course_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>