<?php /* C:\xampp\htdocs\mu_booster_up1\resources\views/layouts/master_admin.blade.php */ ?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?> | Mu-Booster</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/css/fontawesome-all.min.css')); ?>" />
    <!-- Site favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('public/admin_asset/images/favicon.ico')); ?>">
    <!-- Animate Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/css/animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/css/jquery.dataTables.css')); ?>" />
    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/css/bootstrap.min.css')); ?>" />
    <!-- Main Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_asset/css/style.css')); ?>" />
    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin_asset/css/responsive.css')); ?>" media="all" />
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
        <!--Side Bar-->
        <?php echo $__env->make('shared.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Side Bar-->
<div class="admin_area">
    <div class="container-fluid no_padding">

        <!--header Right-->
        <?php echo $__env->make('shared.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--header Right-->

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldContent('box'); ?>
    </div>
</div>

<!-- LinkUp Js -->
<script type="text/javascript" src="<?php echo e(asset('public/admin_asset/js/jquery-1.12.4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/admin_asset/js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/admin_asset/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/admin_asset/js/active.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>