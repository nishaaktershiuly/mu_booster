<?php /* D:\xammp\htdocs\mu_booster_up\resources\views/admin.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="faculty_area">
        <div class="admin_body">
            <h1>Admin Panel</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>