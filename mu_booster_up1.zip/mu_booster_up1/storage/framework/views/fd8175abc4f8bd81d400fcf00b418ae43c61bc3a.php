<?php /* F:\php\htdocs\demo\resources\views/admin/semester/semester.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Semester
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="faculty_area">
	<div class="admin_body">
		<div class="add_faculty">
			<!-- Button trigger modal -->
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal">
				<i class="fa fa-plus-circle"></i>&nbsp; Add Semester
			</button>
			
		</div>		
		<div class="faculty_list">
			<table class="table table-striped" id="dataTable">
				<thead class="thead-dark">
					<tr>
					  <th scope="col">id</th>
					  <th scope="col">Name</th>
					  <th class="text-right">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($i++); ?></th>
						<td><?php echo e($row->name); ?></td>
						<td class="text-right">
							<!-- Button trigger modal -->
							<a data-id="<?php echo e($row->id); ?>" data-name="<?php echo e($row->name); ?>" type="button" class="btn btn-sm btn-success editModal" data-toggle="modal" data-target="#editModal">
                                <i class="fa fa-edit"></i>
							</a>
							<a href="#" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
   <script type="text/javascript">
       $(function () {
           $('.editModal').click(function () {
               var id = $(this).data('id');
               var name = $(this).data('name');

               $('#editFacultyForm [name=id]').val(id);
               $('#editFacultyForm [name=name]').val(name);

           });
       });
	   $(function () {
		   $('#dataTable').DataTable({
			   "order": [[ 0, "DESC" ]],
			   "iDisplayLength": 25,
			   "columnDefs": [
				   { "orderable": false, "targets": 5 }
			   ]
		   });
	   });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('box.semester.semester', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>